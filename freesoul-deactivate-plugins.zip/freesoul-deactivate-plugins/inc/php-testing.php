<?php

// Code to test a site locally taking in account only the PHP performance deactivating one plugin after the other

if ( ! defined( 'ABSPATH' ) ) exit;
$apl = get_option('active_plugins');
$plugins = get_plugins();
$times_all_active = array();
$limit = 10;
for( $n = 0;$n < 10;++$n ){
	$time0 = microtime( true );
	$response = wp_remote_get( $url );
	$body = wp_remote_retrieve_body( $response );
	$times_all_active[] =  ( microtime( true )- $time0 ) * 1000;
}

$times_all_active = array_filter( $times_all_active );
$time_all_active = array_sum( $times_all_active )/count( $times_all_active );

$slow_found = false;
foreach( $apl as $p ){           
    if( isset( $plugins[$p] ) ){
		$plugin = $plugins[$p];
		$time0 = microtime( true );
		$response = wp_remote_get( $url );
        $body = wp_remote_retrieve_body( $response );
		$slow_grade = round( 100 * ( $time_all_active - ( microtime( true )- $time0 ) * 1000 )/$time_all_active,0 );
		if( $slow_grade > $limit ){
			$slow_grades = array();
			//We repeat the test to have a little of statistic
			for( $n = 0;$n < 10;++$n ){
				$time0 = microtime( true );
				$response = wp_remote_get( $url );
				$body = wp_remote_retrieve_body( $response );
				$slow_grades[] = round( 100 * ( $time_all_active - ( microtime( true )- $time0 ) * 1000 )/$time_all_active,0 );			
				
			}
			$slow_grades = array_filter( $slow_grades );
			$slow_grade = array_sum( $slow_grades )/count( $slow_grades );
			if( $slow_grade > $limit ){
				$slow_found = true;
				?>
				<p><?php printf( __( '%s needs too much time for its PHP scripts','eos-dp' ),$plugin['Title'] ); ?></p>
				<p><?php _e( 'It would be a good idea to find an alternative to this plugin','eos-dp' ); ?></p>
				<p><?php printf( __( 'Plugin Description: %s','eos-dp' ),$plugin['Description'] ); ?></p>
				<?php
			}
		}
    }           
}
if( !$slow_found ){
	?>
	<p><?php _e( 'It looks no plugins increase too much the server response time, but you should still check how much they decrease the global performance loading scripts and stylesheets','eos-dp' ); ?></p>
	<?php
}