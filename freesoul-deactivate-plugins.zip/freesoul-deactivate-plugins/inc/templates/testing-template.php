<?php

/**
 * Testing page template
 *
 * Displays the minimum for performance comparison tests
 *
 * @package Freesoul Framework
 * @subpackage Templates
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
} 
?><!DOCTYPE html>
<!--[if IE 7]>
<html class="ie ie7" <?php language_attributes(); ?>>
<![endif]-->
<!--[if IE 8]>
<html class="ie ie8" <?php language_attributes(); ?>>
<![endif]-->
<!--[if !(IE 7) & !(IE 8)]><!-->
<html <?php language_attributes(); ?>>
<!--[endif]-->
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>" />
<meta name="viewport" content="width=device-width" , minimum-scale=1.0, maximum-scale=1.0" />
<title><?php wp_title( '|', true, 'right' ); ?></title>
<?php
wp_head(); 
?>
</head>
<body <?php body_class('eos-dp-performance-test'); ?>>
	<div id="page" class="hfeed site">
		<div id="primary" class="site-content" style="margin-top:0;">
			<div id="content" role="main">
				<?php //We don't need content or comparison tests ?>
				Testing template
			</div>
		</div>
	</div>
<?php wp_footer(); ?>	
</body>
</html>
<?php exit;